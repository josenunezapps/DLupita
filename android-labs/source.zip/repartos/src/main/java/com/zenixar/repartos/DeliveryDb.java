package com.zenixar.repartos;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import org.json.*;
import java.util.*;

public class DeliveryDb extends SQLiteOpenHelper {
  public static class Client {public long id;public String name="",address="",phone="";}
  public static class Delivery {public long id,clientId;public String detail="",date="",status="Pendiente",notes="",photo="",signature="";public double amount=0;public int position=0;}
  public DeliveryDb(Context ctx){super(ctx,"zenix_repartos_v1.db",null,1);}
  @Override public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE clients (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,address TEXT,phone TEXT)");d.execSQL("CREATE TABLE deliveries (id INTEGER PRIMARY KEY AUTOINCREMENT,clientId INTEGER NOT NULL,detail TEXT,date TEXT,status TEXT,notes TEXT,amount REAL,photo TEXT,signature TEXT,position INTEGER)");}
  @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
  private String col(Cursor c,String n){int i=c.getColumnIndex(n);return i<0||c.isNull(i)?"":c.getString(i);}
  private double dbl(Cursor c,String n){int i=c.getColumnIndex(n);return i<0||c.isNull(i)?0:c.getDouble(i);}
  public ArrayList<Client> clients(){ArrayList<Client> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM clients ORDER BY name COLLATE NOCASE",null)){while(c.moveToNext()){Client x=new Client();x.id=c.getLong(c.getColumnIndexOrThrow("id"));x.name=col(c,"name");x.address=col(c,"address");x.phone=col(c,"phone");out.add(x);}}return out;}
  public Client client(long id){try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM clients WHERE id=?",new String[]{""+id})){if(c.moveToFirst()){Client x=new Client();x.id=id;x.name=col(c,"name");x.address=col(c,"address");x.phone=col(c,"phone");return x;}}return null;}
  public long saveClient(Client x){ContentValues cv=new ContentValues();cv.put("name",x.name);cv.put("address",x.address);cv.put("phone",x.phone);if(x.id==0)return getWritableDatabase().insertOrThrow("clients",null,cv);getWritableDatabase().update("clients",cv,"id=?",new String[]{""+x.id});return x.id;}
  public boolean deleteClient(long id){if(count("SELECT COUNT(*) FROM deliveries WHERE clientId=?",new String[]{""+id})>0)return false;getWritableDatabase().delete("clients","id=?",new String[]{""+id});return true;}
  public Delivery delivery(long id){try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM deliveries WHERE id=?",new String[]{""+id})){if(c.moveToFirst())return parse(c);}return null;}
  private Delivery parse(Cursor c){Delivery d=new Delivery();d.id=c.getLong(c.getColumnIndexOrThrow("id"));d.clientId=c.getLong(c.getColumnIndexOrThrow("clientId"));d.detail=col(c,"detail");d.date=col(c,"date");d.status=col(c,"status");d.notes=col(c,"notes");d.photo=col(c,"photo");d.signature=col(c,"signature");d.amount=dbl(c,"amount");d.position=(int)dbl(c,"position");return d;}
  public ArrayList<Delivery> deliveries(){ArrayList<Delivery> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM deliveries ORDER BY CASE WHEN status='Pendiente' THEN 0 WHEN status='En camino' THEN 1 ELSE 2 END, position ASC, date ASC, id DESC",null)){while(c.moveToNext())out.add(parse(c));}return out;}
  public long saveDelivery(Delivery d){ContentValues cv=new ContentValues();cv.put("clientId",d.clientId);cv.put("detail",d.detail);cv.put("date",d.date);cv.put("status",d.status);cv.put("notes",d.notes);cv.put("amount",d.amount);cv.put("photo",d.photo);cv.put("signature",d.signature);cv.put("position",d.position);if(d.id==0)return getWritableDatabase().insertOrThrow("deliveries",null,cv);getWritableDatabase().update("deliveries",cv,"id=?",new String[]{""+d.id});return d.id;}
  public void deleteDelivery(long id){getWritableDatabase().delete("deliveries","id=?",new String[]{""+id});}
  public int count(String sql,String[] args){try(Cursor c=getReadableDatabase().rawQuery(sql,args)){return c.moveToFirst()?c.getInt(0):0;}}
  public JSONObject backup() throws JSONException{JSONObject root=new JSONObject();root.put("version",1);root.put("app","zenix-repartos");JSONArray cls=new JSONArray();for(Client c:clients()){JSONObject o=new JSONObject();o.put("id",c.id);o.put("name",c.name);o.put("address",c.address);o.put("phone",c.phone);cls.put(o);}JSONArray dls=new JSONArray();for(Delivery d:deliveries()){JSONObject o=new JSONObject();o.put("id",d.id);o.put("clientId",d.clientId);o.put("detail",d.detail);o.put("date",d.date);o.put("status",d.status);o.put("notes",d.notes);o.put("amount",d.amount);o.put("photo",d.photo);o.put("signature",d.signature);o.put("position",d.position);dls.put(o);}root.put("clients",cls);root.put("deliveries",dls);return root;}
  public void restore(JSONObject root) throws JSONException{
    if(!"zenix-repartos".equals(root.optString("app"))||root.optInt("version")!=1)throw new JSONException("Respaldo no compatible");JSONArray cls=root.getJSONArray("clients"),dls=root.getJSONArray("deliveries");
    // Validate before changing data; retain IDs so delivery/client links survive.
    HashSet<Long> ids=new HashSet<>();for(int i=0;i<cls.length();i++){JSONObject o=cls.getJSONObject(i);long id=o.getLong("id");if(id<=0||o.optString("name").trim().isEmpty()||!ids.add(id))throw new JSONException("Cliente inválido en respaldo");}
    for(int i=0;i<dls.length();i++){JSONObject o=dls.getJSONObject(i);if(!ids.contains(o.getLong("clientId")))throw new JSONException("Hay entregas sin cliente en respaldo");}
    SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{d.delete("deliveries",null,null);d.delete("clients",null,null);
      for(int i=0;i<cls.length();i++){JSONObject o=cls.getJSONObject(i);ContentValues v=new ContentValues();v.put("id",o.getLong("id"));v.put("name",o.getString("name"));v.put("address",o.optString("address"));v.put("phone",o.optString("phone"));d.insertOrThrow("clients",null,v);}
      for(int i=0;i<dls.length();i++){JSONObject o=dls.getJSONObject(i);ContentValues v=new ContentValues();v.put("id",o.getLong("id"));v.put("clientId",o.getLong("clientId"));v.put("detail",o.optString("detail"));v.put("date",o.optString("date"));v.put("status",o.optString("status","Pendiente"));v.put("notes",o.optString("notes"));v.put("photo",o.optString("photo"));v.put("signature",o.optString("signature"));v.put("amount",o.optDouble("amount"));v.put("position",o.optInt("position"));d.insertOrThrow("deliveries",null,v);}
      d.setTransactionSuccessful();
    }finally{d.endTransaction();}
  }
}
