package com.zenixar.repartos;
import android.content.Context;
import android.graphics.*;
import android.view.*;
public class SignPad extends View {
 private final Path path=new Path();private final Paint pen=new Paint(3);private final Paint hint=new Paint(3);
 private boolean empty=true;
 public SignPad(Context context){super(context);setBackgroundColor(Color.WHITE);pen.setColor(Color.rgb(24,60,91));pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(5);pen.setStrokeJoin(Paint.Join.ROUND);pen.setStrokeCap(Paint.Cap.ROUND);hint.setColor(Color.rgb(210,217,225));hint.setStrokeWidth(2);setMinimumHeight(240);}
 @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawLine(15,getHeight()-40,getWidth()-15,getHeight()-40,hint);c.drawPath(path,pen);}
 @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==MotionEvent.ACTION_DOWN){path.moveTo(x,y);empty=false;invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){path.lineTo(x,y);invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){path.lineTo(x,y);invalidate();performClick();return true;}return true;}
 @Override public boolean performClick(){super.performClick();return true;}
 public void clear(){path.reset();empty=true;invalidate();}
 public boolean isEmpty(){return empty;}
 public Bitmap capture(){Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);draw(c);return b;}
}
