package com.zenixar.fotopro;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.util.*;
import java.io.*;

public class MainActivity extends Activity {
  private static final int PICK=400;
  private final int INK=Color.rgb(25,36,57), NAVY=Color.rgb(18,28,49), BLUE=Color.rgb(72,93,228), PALE=Color.rgb(245,247,252);
  private final int[] BG={Color.WHITE,Color.rgb(243,244,247),Color.rgb(245,233,217),Color.rgb(232,240,246),Color.rgb(25,32,48),Color.rgb(240,220,221)};
  private final String[] BG_NAMES={"Blanco","Perla","Arena","Azul hielo","Grafito","Rosa"};
  private final String[] FORMATS={"Cuadrado 1:1","Catálogo 4:5","Historia 9:16"};
  private ArrayList<Uri> uris=new ArrayList<>();
  private int selected=0,bgIndex=0,format=0;
  private boolean clean=false,shadow=true;
  private String tag="",price="";
  private LinearLayout root,content,thumbnails;
  private TextView infoLabel,headerCount;
  private ImageView preview;
  private Handler handler=new Handler(Looper.getMainLooper());
  private boolean busy=false;

  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);show();}
  private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  private GradientDrawable shape(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
  private GradientDrawable stroke(int c,int outline,int r){GradientDrawable g=shape(c,r);g.setStroke(dp(1),outline);return g;}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setFontFeatureSettings("kern");if(bold)t.setTypeface(null,1);return t;}
  private LinearLayout v(){LinearLayout a=new LinearLayout(this);a.setOrientation(1);return a;}
  private LinearLayout h(){LinearLayout a=new LinearLayout(this);a.setOrientation(0);a.setGravity(Gravity.CENTER_VERTICAL);return a;}
  private void pad(View view,int l,int t,int r,int b){view.setPadding(dp(l),dp(t),dp(r),dp(b));}
  private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
  private void gap(LinearLayout parent,int height){View x=new View(this);parent.addView(x,lp(1,height));}
  private Button button(String label,int color,boolean white,Runnable action){Button b=new Button(this);b.setText(label);b.setTextAllCaps(false);b.setTextSize(12);b.setTypeface(null,1);b.setTextColor(white?Color.WHITE:INK);b.setBackground(shape(color,12));b.setMinHeight(0);b.setMinimumHeight(0);b.setOnClickListener(x->action.run());return b;}
  private void show(){
    root=v();root.setBackgroundColor(PALE);setContentView(root);
    LinearLayout head=v();head.setBackgroundColor(NAVY);pad(head,22,20,20,18);root.addView(head,lp(-1,-2));
    TextView mark=txt("ZENIX AR   /   HERRAMIENTAS PARA VENDER",10,Color.rgb(147,169,206),true);head.addView(mark);
    gap(head,8);TextView title=txt("FotoPro",29,Color.WHITE,true);head.addView(title);
    TextView sub=txt("Tu estudio de productos, en el celular.",13,Color.rgb(190,204,228),false);head.addView(sub);gap(head,14);
    LinearLayout topActions=h();head.addView(topActions,lp(-1,-2));
    Button imp=button("＋ Importar fotos",BLUE,true,this::pick);topActions.addView(imp,new LinearLayout.LayoutParams(0,dp(45),1));
    View sep=new View(this);topActions.addView(sep,lp(10,1));
    Button export=button("Guardar",Color.WHITE,false,()->export(false));topActions.addView(export,lp(112,45));
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    content=v();pad(content,17,17,17,27);scroll.addView(content);
    LinearLayout summary=h();content.addView(summary,lp(-1,-2));
    TextView section=txt("VISTA PREVIA",11,Color.rgb(105,117,140),true);summary.addView(section,new LinearLayout.LayoutParams(0,dp(32),1));
    headerCount=txt("0 imágenes",12,BLUE,true);summary.addView(headerCount);
    LinearLayout prevFrame=v();pad(prevFrame,12,12,12,12);prevFrame.setBackground(stroke(Color.WHITE,Color.rgb(225,232,243),18));content.addView(prevFrame,lp(-1,-2));
    preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);prevFrame.addView(preview,lp(-1,310));
    infoLabel=txt("Importá una o varias fotografías para comenzar.",12,Color.rgb(117,128,149),false);pad(infoLabel,8,9,8,0);prevFrame.addView(infoLabel);
    gap(content,14);
    thumbnails=h();content.addView(thumbnails,lp(-1,-2));
    gap(content,20);
    panelLabel("01 · FORMATO DE PUBLICACIÓN");
    chipRow(FORMATS,format,i->{format=i;show();});
    gap(content,16);panelLabel("02 · FONDO PARA EL PRODUCTO");
    chipRow(BG_NAMES,bgIndex,i->{bgIndex=i;show();});
    gap(content,16);panelLabel("03 · TERMINACIÓN");
    settingSwitch("Sombra sutil bajo el producto",shadow,x->{shadow=x;refresh();});
    settingSwitch("Limpiar fondo uniforme (experimental)",clean,x->{clean=x;refresh();});
    TextView hint=txt("La limpieza funciona mejor sobre fondos lisos. No es recorte con IA; verificá el resultado antes de exportar.",11,Color.rgb(127,137,153),false);pad(hint,6,8,6,4);content.addView(hint);
    gap(content,18);panelLabel("04 · TEXTO Y MARCA");
    Button watermark=button("Marca: "+(tag.isEmpty()?"Sin marca de agua":tag),Color.WHITE,false,()->askText("Marca de agua",tag,v->{tag=v;show();}));content.addView(watermark,lp(-1,45));gap(content,9);
    Button amount=button("Precio / etiqueta: "+(price.isEmpty()?"Sin etiqueta":price),Color.WHITE,false,()->askText("Texto o precio",price,v->{price=v;show();}));content.addView(amount,lp(-1,45));gap(content,16);
    Button all=button("⬇ Exportar todas las fotos",BLUE,true,()->export(true));content.addView(all,lp(-1,50));
    gap(content,8);TextView note=txt("Archivos PNG de 1080 px · Se guardan en Imágenes/ZenixFotoPro · Funciona sin internet",11,Color.rgb(123,135,152),false);note.setGravity(Gravity.CENTER);content.addView(note);
    refresh();
  }
  private interface IndexConsumer{void accept(int n);}
  private interface TextConsumer{void accept(String s);}
  private interface BoolConsumer{void accept(boolean b);}
  private void panelLabel(String text){TextView label=txt(text,11,INK,true);content.addView(label);gap(content,8);}
  private void chipRow(String[] vals,int active,IndexConsumer cb){
    HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);content.addView(sc,lp(-1,47));
    LinearLayout row=h();sc.addView(row);
    for(int i=0;i<vals.length;i++){final int n=i;TextView item=txt(vals[i],12,i==active?Color.WHITE:INK,true);pad(item,14,0,14,0);item.setGravity(Gravity.CENTER);item.setBackground(stroke(i==active?BLUE:Color.WHITE,i==active?BLUE:Color.rgb(221,228,239),12));LinearLayout.LayoutParams p=lp(-2,40);p.setMargins(0,0,dp(8),0);row.addView(item,p);item.setOnClickListener(w->cb.accept(n));}
  }
  private void settingSwitch(String title,boolean checked,BoolConsumer cb){
    Switch sw=new Switch(this);sw.setText(title);sw.setTextSize(13);sw.setTextColor(INK);sw.setChecked(checked);pad(sw,9,12,9,12);sw.setOnCheckedChangeListener((x,value)->cb.accept(value));content.addView(sw,lp(-1,-2));
  }
  private void askText(String title,String current,TextConsumer save){EditText e=new EditText(this);e.setSingleLine(true);e.setText(current);e.setSelectAllOnFocus(true);e.setInputType(InputType.TYPE_CLASS_TEXT);new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("Cancelar",null).setNeutralButton("Borrar",(d,w)->save.accept("")).setPositiveButton("Aceptar",(d,w)->save.accept(e.getText().toString().trim())).show();}
  private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,PICK);}
  @Override protected void onActivityResult(int code,int result,Intent data){super.onActivityResult(code,result,data);if(result!=RESULT_OK||data==null||code!=PICK)return;ArrayList<Uri> u=new ArrayList<>();if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)u.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null){u.add(data.getData());}int flags=data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION;for(Uri uri:u){try{getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}if(!uris.contains(uri))uris.add(uri);}selected=0;show();}
  private void refresh(){
    if(preview==null)return;headerCount.setText(uris.size()+" imagen"+(uris.size()==1?"":"es"));thumbnails.removeAllViews();
    if(uris.isEmpty()){preview.setImageDrawable(null);preview.setBackground(shape(BG[bgIndex],10));infoLabel.setText("Sin fotografías cargadas. Tocá «Importar fotos».");return;}
    for(int i=0;i<uris.size();i++){final int ix=i;TextView b=txt((i==selected?"● ":"")+"Foto "+(i+1),11,i==selected?Color.WHITE:INK,true);b.setGravity(Gravity.CENTER);b.setBackground(shape(i==selected?NAVY:Color.WHITE,11));LinearLayout.LayoutParams p=lp(83,37);p.setMargins(0,0,dp(7),0);thumbnails.addView(b,p);b.setOnClickListener(x->{selected=ix;refresh();});}
    infoLabel.setText("Foto "+(selected+1)+" de "+uris.size()+" · Vista previa del resultado");
    try{Bitmap result=render(uris.get(selected),600);preview.setImageBitmap(result);preview.setBackgroundColor(BG[bgIndex]);}catch(Exception ex){infoLabel.setText("No se pudo abrir esta foto: "+ex.getMessage());}
  }
  private Bitmap read(Uri uri,int bound) throws IOException {
    BitmapFactory.Options dimensions=new BitmapFactory.Options();dimensions.inJustDecodeBounds=true;
    try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,dimensions);}
    if(dimensions.outWidth<=0)throw new IOException("Formato no compatible");
    BitmapFactory.Options o=new BitmapFactory.Options();int largest=Math.max(dimensions.outWidth,dimensions.outHeight);o.inSampleSize=1;while(largest/o.inSampleSize>bound*2)o.inSampleSize*=2;
    try(InputStream in=getContentResolver().openInputStream(uri)){Bitmap b=BitmapFactory.decodeStream(in,null,o);if(b==null)throw new IOException("Imagen dañada");return b;}
  }
  private Bitmap removeUniform(Bitmap source){
    int w=source.getWidth(),h=source.getHeight();if(w*h>4500000)return source;
    int[] src=new int[w*h];source.getPixels(src,0,w,0,0,w,h);
    int[] corners={src[0],src[w-1],src[(h-1)*w],src[h*w-1]};
    long rr=0,gg=0,bb=0;for(int x:corners){rr+=Color.red(x);gg+=Color.green(x);bb+=Color.blue(x);}int cr=(int)(rr/4),cg=(int)(gg/4),cb=(int)(bb/4);
    int disagreements=0;for(int x:corners){int d=Math.abs(Color.red(x)-cr)+Math.abs(Color.green(x)-cg)+Math.abs(Color.blue(x)-cb);if(d>65)disagreements++;}
    if(disagreements>0)return source;
    boolean[] done=new boolean[src.length];int[] queue=new int[src.length];int read=0,write=0;
    for(int x=0;x<w;x++){queue[write++]=x;done[x]=true;int j=(h-1)*w+x;if(!done[j]){done[j]=true;queue[write++]=j;}}
    for(int y=1;y<h-1;y++){int a=y*w;if(!done[a]){done[a]=true;queue[write++]=a;}int b=a+w-1;if(!done[b]){done[b]=true;queue[write++]=b;}}
    while(read<write){int i=queue[read++],px=src[i];int delta=Math.abs(Color.red(px)-cr)+Math.abs(Color.green(px)-cg)+Math.abs(Color.blue(px)-cb);
      if(delta>70)continue;src[i]=px&0x00ffffff;
      int x=i%w;if(x>0&&!done[i-1]){done[i-1]=true;queue[write++]=i-1;}if(x<w-1&&!done[i+1]){done[i+1]=true;queue[write++]=i+1;}if(i>=w&&!done[i-w]){done[i-w]=true;queue[write++]=i-w;}if(i<src.length-w&&!done[i+w]){done[i+w]=true;queue[write++]=i+w;}
    }
    Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);out.setPixels(src,0,w,0,0,w,h);return out;
  }
  private Bitmap render(Uri uri,int base) throws IOException{
    Bitmap b=read(uri,base*2);if(clean)b=removeUniform(b);
    int ow=base,oh=format==0?base:format==1?Math.round(base*1.25f):Math.round(base*1.77778f);
    Bitmap canvasBm=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);Canvas cv=new Canvas(canvasBm);cv.drawColor(BG[bgIndex]);
    float roomW=ow*.82f,roomH=oh*.67f;float factor=Math.min(roomW/b.getWidth(),roomH/b.getHeight());float pw=b.getWidth()*factor,ph=b.getHeight()*factor;float x=(ow-pw)/2f,y=(oh-ph)/2f;
    if(shadow){Paint shadowPaint=new Paint(3);shadowPaint.setColor(Color.argb(34,0,0,0));shadowPaint.setShadowLayer(base*.03f,0,base*.016f,Color.argb(65,0,0,0));cv.drawOval(ow*.29f,y+ph*.97f,ow*.71f,y+ph*1.01f,shadowPaint);}
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);cv.drawBitmap(b,null,new RectF(x,y,x+pw,y+ph),p);
    int fg=bgIndex==4?Color.WHITE:INK;
    if(!price.isEmpty()){
      Paint strip=new Paint(3);strip.setColor(bgIndex==4?Color.argb(190,255,255,255):Color.argb(235,255,255,255));
      float w=ow*.82f,h=base*.095f,left=ow*.09f,top=oh-base*.23f;cv.drawRoundRect(new RectF(left,top,left+w,top+h),base*.025f,base*.025f,strip);
      Paint label=new Paint(3);label.setColor(INK);label.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));label.setTextSize(base*.048f);String value=price;while(label.measureText(value)>w-base*.045f&&value.length()>1){value=value.substring(0,value.length()-1);}cv.drawText(value,left+base*.022f,top+base*.061f,label);
    }
    if(!tag.isEmpty()){
      Paint water=new Paint(3);water.setColor(fg);water.setAlpha(bgIndex==4?185:115);water.setTextSize(base*.035f);water.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));String value=tag;while(water.measureText(value)>ow*.75f&&value.length()>1)value=value.substring(0,value.length()-1);cv.drawText(value,ow*.5f-water.measureText(value)/2,oh-base*.048f,water);
    }
    if(b!=canvasBm&&!b.isRecycled())b.recycle();return canvasBm;
  }
  private void export(boolean all){if(busy)return;if(uris.isEmpty()){toast("Primero importá fotografías");return;}busy=true;Toast.makeText(this,"Preparando imágenes...",Toast.LENGTH_SHORT).show();new Thread(()->{int ok=0;String error="";int start=all?0:selected,end=all?uris.size():selected+1;
    for(int i=start;i<end;i++){try{Bitmap bm=render(uris.get(i),1080);String filename="ZenixFotoPro_"+System.currentTimeMillis()+"_"+(i+1)+".png";ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,filename);values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ZenixFotoPro");values.put(MediaStore.Images.Media.IS_PENDING,1);Uri target=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(target==null)throw new IOException("No se puede guardar la imagen");try(OutputStream out=getContentResolver().openOutputStream(target)){if(out==null||!bm.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("Error al guardar PNG");}values.clear();values.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(target,values,null,null);bm.recycle();ok++;}catch(Exception ex){error=ex.getMessage();}}
    final int done=ok,expected=end-start;final String issue=error;handler.post(()->{busy=false;new AlertDialog.Builder(this).setTitle("Exportación finalizada").setMessage(done+" de "+expected+" imágenes guardadas en la galería, carpeta ZenixFotoPro."+(issue.isEmpty()?"":"\n\nÚltimo error: "+issue)).setPositiveButton("Entendido",null).show();});
   }).start();}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
