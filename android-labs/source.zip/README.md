# Zenix AR · Aplicaciones Android nativas (MVP offline)

Dos proyectos Android independientes, escritos en Java sin SDKs pagos ni conexión obligatoria.

- **Zenix FotoPro** (`:fotopro`): importa fotografías de productos desde el selector de Android, fondos comerciales, tamaños 1:1 / 4:5 / 9:16, retoque básico opcional de fondo uniforme, marca de agua, etiquetas y exportación individual o por lotes a la galería.
- **Zenix Repartos** (`:repartos`): clientes, entregas, estados, rutas externas a Google Maps, foto de comprobante, firma táctil, reporte PDF individual, compartir por WhatsApp y respaldo JSON.

## Compilar

Android Studio con JDK 17 y Android SDK 35. Gradle 8.11.1 / Android Gradle Plugin 8.7.3.

`gradle :fotopro:assembleDebug :repartos:assembleDebug`

El repositorio contiene código fuente; para instalar se usa un APK compilado. La compilación de CI publica artefactos de demostración cuando la acción concluye sin errores.

## Límites deliberados del MVP

FotoPro no integra recorte de fondo con IA: el botón de limpieza funciona **solo con fondos uniformes** y puede afectar objetos del mismo color; por defecto permanece desactivado. No está conectada a tiendas online ni procesa pagos.

Repartos guarda todo **localmente** en SQLite y archivos del dispositivo. La app no sincroniza con otros dispositivos ni optimiza rutas automáticamente; abre el navegador o Google Maps para navegar por los domicilios cargados. Las firmas y fotos son comprobantes internos, no verificación legal de entrega.

Antes de usar con información de clientes reales, implementar autenticación, política de privacidad, seguridad de datos, pruebas en distintos dispositivos y sincronización si se usará en equipos de repartidores.
